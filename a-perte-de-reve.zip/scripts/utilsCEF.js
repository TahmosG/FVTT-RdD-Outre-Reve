const debugCEF = true;
function logCEF(...args){
  if(debugCEF){
    console.log("OUTRE-REVE || ", ...args)
  }
}

// include "/modules/a-perte-de-reve/config/const-cef.js";
// import { CarteCEF, cartesHR, RdDCEFDialog } from "/modules/a-perte-de-reve/modules/Carte-CEF.js";
// import { Arpenteur } from "/modules/a-perte-de-reve/modules/arpenteur.js";
// import { RdDRencontreCEF, tablesRencontres } from "/modules/a-perte-de-reve/modules/rencontre-cef.js";

// class utilsCEF {
//   static arpenteur = Arpenteur;
//   static carteCEF = CarteCEF;
//   static rencontreCEF = RdDRencontreCEF;

// }