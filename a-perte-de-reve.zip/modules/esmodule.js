// Import from RdD System --> utilities & hooks
import { TMRUtility } from "/systems/foundryvtt-reve-de-dragon/module/tmr-utility.js";
import { RdDTMRDialog } from "/systems/foundryvtt-reve-de-dragon/module/rdd-tmr-dialog.js";
import { CarteTmr } from "/systems/foundryvtt-reve-de-dragon/module/tmr/carte-tmr.js";
import { EffetsDraconiques } from "/systems/foundryvtt-reve-de-dragon/module/tmr/effets-draconiques.js";
import { Draconique } from "/systems/foundryvtt-reve-de-dragon/module/tmr/draconique.js";
//import { EffetsRencontre } from "/systems/foundryvtt-reve-de-dragon/module/tmr/effets-rencontres.js";
//import { RdDRencontre } from "/systems/foundryvtt-reve-de-dragon/module/item/rencontre.js";

// Import from OutreReve Module --> new classes
import "/modules/a-perte-de-reve/config/const-cef.js";
import { CarteCEF, cartesHR, RdDCEFDialog } from "/modules/a-perte-de-reve/modules/Carte-CEF.js";
import { Arpenteur } from "/modules/a-perte-de-reve/modules/arpenteur.js";
import { RdDRencontreCEF, CEFRencontres } from "/modules/a-perte-de-reve/modules/rencontre-cef.js";
//import { CEFUtilities } from "/modules/a-perte-de-reve/templates/dialog-CEFUtilities.hbs";

/*****************************************************************************************************
 * To make this module work, the following change had to be applied to the original Game System:
 *   - /item/rencontre.js line 4: "export" const tableEffets = [
 *   - 
******************************************************************************************************/

    /** Allow toggling between TMR-CEF: 
     *      [V] Illustration de la Carte
     *      [V] Mapping du nom et type de Cases 
     *      [V] Jet de Rencontre selon climat
     *      [~] Table des Rencontres
     *      [x] Effet des Rencontre sur le Climat  
     *         --> effet: 'effets-rencontre.js' line 26
                         static climat_plus_1 = async (dialog, context) => { await EffetsRencontre.$climat_plus(context.actor, 1) } //Tahmos
                         static climat_moins_1 = async (dialog, context) => { await EffetsRencontre.$climat_plus(context.actor, -1) } //Tahmos
                         static $climat_plus = async (actor, clim) => {
                              await actor.AjusteClimat(clim);
                         }
     *         --> liste: 'rencontre.js' line 
                         { code: "climat+1", resultat: "echec", description: "le climat CEF monte de 1", method: EffetsRencontre.climat_plus_1 },
                         { code: "climat-1", resultat: "echec", description: "le climat CEF descend de 1", method: EffetsRencontre.climat_moins_1 },
    */ 

/*********************************
 **      INITIALIZATION         **
**********************************/
console.log(`OUTRE-REVE || ESModule - Initializing`);
Hooks.once("ready", function() {
     console.log("OUTRE-REVE || ESModule (onReady) REGISTERING Utilities");
     game.outreReve = { 
          TMRUtility, cartesHR,
          EffetsDraconiques, 
          CarteTmr, CarteCEF, 
          RdDTMRDialog, RdDCEFDialog, 
          Arpenteur, RdDRencontreCEF, CEFRencontres,
          OutreReve
     };

     console.log("OUTRE-REVE || ESModule (onReady) REGISTERING TMR & CEF");
     Draconique.register(game.outreReve.cartesHR["TMR"]);
     Draconique.register(game.outreReve.cartesHR["CEF"]);

     console.log("OUTRE-REVE || ESModule (onReady) INITIALIZING CEF & Rencontres");
     // tablesRencontres.init();
     //CEFRencontres.init();
     RdDRencontreCEF.init();
     Arpenteur.initAll();


     console.log("OUTRE-REVE || ESModule (onReady) REGISTERING Wrappers");
     initWrapper();

     console.log("OUTRE-REVE || ESModule (onReady) REGISTERING HandleBars");
     OutreReve.preloadHandlebarsTemplates();
});

async function initWrapper() {
     // Hook pour le jet de Rencontre --> line 670:  static async _jetDeRencontre(tmr) {
     await libWrapper.register('a-perte-de-reve', 'game.outreReve.RdDTMRDialog.create', async function (wrapped, ...args) {
          //console.log(`OUTRE-REVE || libWrapper() - RdDTMRDialog.create kicked in`, ...args);
          const result = await game.outreReve.RdDCEFDialog.create(...args);
          return result; // RdDTMRDialog --> RdDCEFDialog
     }, );
     // hook des TMRUtilities (pour mapping cases)
     await libWrapper.register('a-perte-de-reve', 'game.outreReve.TMRUtility.getTMRLabel', function (wrapped, ...args) {
          //console.log(`OUTRE-REVE || libWrapper() - TMRUtility.getTMRLabel kicked in`, ...args);
          let selected = game.system.rdd.RdDUtility.getSelectedActor();
          if (game.outreReve.Arpenteur.CarteActuelle(selected) == "CEF"){   // ameliorable !
               return game.outreReve.CarteCEF.getCEFLabel(...args);
          } else { // TMR
               return wrapped(...args);           return result;
          }
     }, );
     //RdDRencontre.newEffect =   static reve_plus_force = async (dialog, context) => { await EffetsRencontre.$reve_plus(context.actor, context.rencontre.system.force) }
};

/*****************************
 **      OUTRE-REVE         **
******************************/
class OutreReve {

     // Popup avec les fonctions de base pour gerer les nouvelles data
     static async dialogUtilities1 (){
          /*const template = "/modules/a-perte-de-reve/templates/dialog-CEFUtilities.hbs";
          const html = await renderTemplate(template, {} );

          return Promise(); */
     }
     static async dialogUtilities2 (){
          /*const myDialog = new Dialog({
               title: "Outre-Rêve: Utilitaires",
             content: CEFUtilities,
             buttons: {}
           }).render(true);*/
     }

     static refreshCarte(arpenteur){
               CEFRencontres.init();

          let destination = arpenteur.CEF.CarteActuelle();
          console.log('OUTRE-REVE || mise a jour de la Carte en destination de ', destination);
          
          // mise a jour des info de tmrDialog
          let message = (destination == "CEF") 
               ? "Les Eaux du Fleuve" 
               : "Les Terres Médianes du Rêve";
          arpenteur.tmrApp.pixiTMR.tmrDialog.data.title = message;
          //arpenteur.tmrApp.pixiTMR.tmrDialog.data.buttons = buttonTMR_CEF;
          //console.log("CONTENT = ", arpenteur.tmrApp.pixiTMR.tmrDialog.data.content);

          // mise a jour et rafraichissement de l'image de la Carte
          game.outreReve.EffetsDraconiques.carteTmr = game.outreReve.cartesHR[destination];
          arpenteur.tmrApp.externalRefresh();
          return ;
     }

     static preloadHandlebarsTemplates() {

          // Register Sheets (rdd-main.js - line 203)
          //   [x] Sorts --> transcription + Synthese
          //   [x] Parchemin --> lecture + synthese
          // Items.registerSheet(SYSTEM_RDD, RdDItemSheet, {
          //      types: [
          //        "competence", "competencecreature",
          //        "recettealchimique", "musique", "chant", "danse", "jeu", "race",
          //        "recettecuisine", "oeuvre", "meditation",
          //        "queue", "ombre", "souffle", "tete", "casetmr", "sort", "sortreserve",
          //        "nombreastral", "tache", "maladie", "poison", "possession",
          //        "tarot", "extraitpoetique", "empoignade"
          //      ],
          //      makeDefault: true
          // })
          // RdDItemSheet.register(RdDRencontreItemSheet)


          /** from "rdd-utility.js" 
          // const templatePaths = [ list all the .hbs ]

          // TMRs
          Handlebars.registerHelper('caseTmr-label', coord => TMRUtility.getTMRLabel(coord));
          Handlebars.registerHelper('caseTmr-type', coord => TMRUtility.getTMRType(coord));
          Handlebars.registerHelper('typeTmr-name', type => TMRUtility.typeTmrName(type));
          Handlebars.registerHelper('effetRencontre-name', coord => TMRUtility.typeTmrName(coord));
          //loadTemplates(templatePaths);
          */
     }
     /** from rdd-main.js        
     RdDItemSheet.register(RdDRencontreItemSheet)
     */
}