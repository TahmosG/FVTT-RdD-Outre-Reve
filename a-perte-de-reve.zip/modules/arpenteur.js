import { TMRUtility } from "/systems/foundryvtt-reve-de-dragon/module/tmr-utility.js";
/** TO DO
 *  [x] Rencontres changent le Climat
 *  [x] quand bascule: fatigue +1 
 *  [x] quand bascule: tirer rencontre
 *  [x] Temperer le Climat : -(qualité) Maitrise du Fleuve avec ARPENTAGE
 *  [x] Temperer le Climat : -1 au Chateau dormant
 */
export class Arpenteur {
    static liste = []; //liste des Arpenteurs reconnus
    constructor (perso){
        //ui.notifications.info(`OUTRE-REVE || Creation de l'objet ARPENTEUR pour ${perso.name}`); 
        this.acteur = perso;
    }
    static async initAll(){
        console.log (`OUTRE-REVE || Initialization des Arpenteurs: `);
        Arpenteur.liste.length = 0;
        await game.actors.forEach( element => { this.init(element) } )
        console.log (`OUTRE-REVE || Initialization des Arpenteurs: `, Arpenteur.liste);
    }
    static async init(perso){
        // DEV-NOTE : ajouter un hook lors de l'ajout/suppression du Don d'Arpentage + automatiquement ajouter la Competence !
        if (this._donArpentage(perso)){
            console.log(`OUTRE-REVE || Initialization des Arpenteurs - ${perso.name} possède le don d'Arpentage`);
            Arpenteur.liste.push(perso);
            if (perso.getFlag(`a-perte-de-reve`, `isArpenteur`) != true){ // si true, pas besoin d'overide les Flags
                await perso.setFlag(`a-perte-de-reve`, `isArpenteur`, true);
                await perso.setFlag(`a-perte-de-reve`, `Imago`, true);
                await perso.setFlag(`a-perte-de-reve`, `Climat`, 1);
                console.log(`OUTRE-REVE || Initialization des Arpenteurs - Initialization des FLAGs pour ${perso.name}`); 
            }
        } else {
            console.log(`OUTRE-REVE || Initialization des Arpenteurs - ${perso.name} n'a pas le don d'Arpentage`);
            await perso.setFlag(`a-perte-de-reve`, `isArpenteur`, false);
            await perso.setFlag(`a-perte-de-reve`, `Imago`, "N/A");
            await perso.setFlag(`a-perte-de-reve`, `Climat`, 0); // 0 = climat TMR
        }
        // Ajout d'un Objet TEMPORAIRE dans l'ACTEUR
        if (!perso.CEF) { perso.CEF = new Arpenteur(perso); }
        return perso.CEF;
    }
    static async clearAll(){
        console.log (`OUTRE-REVE || Initialization des Arpenteurs: `);
        await game.actors.forEach( element => { this.clearFlags(element) } )
    }
    static async clearFlags (arpenteur, init = false) { 
        arpenteur.clearFlags(init)
    }
    static _donArpentage (perso) {
        return (perso.items.filter(item => item.name == "Don d'Arpenter le Fleuve").length > 0) ? true : false;
    }

    /**************************
     *      OBJECT Methods    *
     **************************/ 
    isArpenteur(){ 
        return this.acteur.getFlag(`a-perte-de-reve`, `isArpenteur`);
    }
    isImago(){ 
        return this.acteur.getFlag(`a-perte-de-reve`, `Imago`);
    }
    CarteActuelle() { 
        let imago = this.acteur.getFlag(`a-perte-de-reve`, `Imago`);
        if (imago == true) {  
            return "CEF";
        } else {       
            return "TMR";
        }
    }
    EtatActuel() { 
        let imago = this.acteur.getFlag(`a-perte-de-reve`, `Imago`);
        let result = "";
        if (this.acteur?.tmrApp == undefined){
            result = "Vrai-Rêve"
        } else {
            result = (imago == true) ? "Imago" : "Demi-Rêve";
        }
        console.log("OUTRE-REVE ||", this.acteur.name,"est en", result);
        return result;
    }
    ClimatActuel() { 
        return this.acteur.getFlag(`a-perte-de-reve`, `Climat`);
    }
    RencontreMin(){
        ui.notifications.info(RDD_CEF.Climat[this.ClimatActuel()].label, ":", RDD_CEF.Climat[this.ClimatActuel()].rencontreMin);
        return RDD_CEF.Climat[this.ClimatActuel()].rencontreMin;
    }
    LogArpenteur() { 
        if ( this.isArpenteur == true){
            ui.notifications.info(`OUTRE-REVE || ${this.acteur.name} a son ${this.EtatActuel()} en ${this.CarteActuelle()} (Climat = ${this.ClimatActuel()})`); 
        } else {
            ui.notifications.info(`OUTRE-REVE || ${this.acteur.name} n'a pas le Don d'Arpenter le Fleuve`); 
        }
    }

    async basculerTmrCEF (destination = "", forced = false) { 
        /** REGLES: 
         *  [V] Passage TMR --> CEF uniquement via Cases Humides
         *  [x] Perte de -1 fatigue ; 
         *  [x] Risque de Rencontre sur carte de Destination */

        //  VERIFICATIONS
        //-----------------
        if (!this.isArpenteur()) { 
             ui.notifications.warn(`${this.acteur.name} n'est pas un Arpenteur`);
             return false
        };
        if (forced == false){
            if (!this.acteur.tmrApp) { 
                ui.notifications.warn(`${this.acteur.name} doit etre en Demi-Rêve pour basculer entre TMR <-> CEF`);
                return false;
            }
            if (destination == this.CarteActuelle()){
                ui.notifications.info(`${this.acteur.name} est deja en ${destination}`);
                return;            
            } 
            let pos = TMRUtility.getTMR(this.acteur.system.reve.tmrpos.coord);
            if( !this.isImago() && !TMRUtility.isCaseHumide(pos) ){ 
                ui.notifications.info(`${this.acteur.name} doit être sur une Case Humide pour basculer en CEF`);
                return false
            }
        }
        //  BASCULEMENT
        //---------------
        await this._basculer();
    }
    async _basculer(){ // Transition entre CEF <--> TMR
        // changement du status de l'Arpenteur
        let imago = !this.acteur.getFlag(`a-perte-de-reve`, `Imago`)
        await this.acteur.setFlag(`a-perte-de-reve`, `Imago`, imago);
        
        // Changement de la Carte  // + changement Mapping des cases (gerer via hook)
        let carte = this.CarteActuelle();
        game.outreReve.OutreReve.refreshCarte(this.acteur);
        console.log(`OUTRE-REVE || Arpentage - ${this.acteur.name} bascule en ${carte} : ${this.ClimatActuel()}`); 
        
        // changer les Rencontres
        // this.toggleRencontres(arpenteur);
        return carte;
    } 
    async clearFlags (init = false) { 
        const confirm = await Dialog.confirm({ 
            content: `Etes-vous sur de vouloir reinitialiser les Flags d'Arpentage pour ${this.acteur.name} ? \n (Climat actuel == ${this.ClimatActuel()})`  })
        if (confirm){ 
            await this.acteur.unsetFlag(`a-perte-de-reve`, `isArpenteur`);
            await this.acteur.unsetFlag(`a-perte-de-reve`, `Imago`);
            await this.acteur.unsetFlag(`a-perte-de-reve`, `Climat`);
            ui.notifications.info(`OUTRE-REVE || Arpenteur - Reset des FLAGs d'arpentage pour ${this.acteur.name}`);
            if (init) { Arpenteur.initAll(); }
        }
    }

    /**************************
     *      CLASS Methods     *         DEPRECATED !!!!
     **************************/ 
    static isArpenteur(selected){
        if (!selected) { 
          // pas de perso selectionné
          ui.notifications.info(`Pas de personnage sélectionné`);
          return undefined;
        }   
        return selected.CEF.isArpenteur(); 
    }
    static CarteActuelle (arpenteur) { 
        let imago = arpenteur.getFlag(`a-perte-de-reve`, `Imago`);
        if (imago == true) {
            return "CEF";
        } else {
            return "TMR";
        }
    }
    static EtatActuelle (arpenteur) { 
        let imago = arpenteur.getFlag(`a-perte-de-reve`, `Imago`);
        let result;
        if (arpenteur?.tmrApp == undefined){
            result = "Vrai-Rêve"
        } else if (imago == true) {
            result = "Imago";
        } else {
            result = "Demi-Rêve";
        }
        console.log(arpenteur.name,"est en", result);
        return result;
    }
    static ClimatActuel (arpenteur) { 
        return arpenteur.getFlag(`a-perte-de-reve`, `Climat`);
    }
    static LogArpenteur (arpenteur) { 
        let arp = arpenteur.getFlag(`a-perte-de-reve`, `isArpenteur`);
        if ( arp == true){
            ui.notifications.info(`OUTRE-REVE || ${arpenteur.name} a son ${this.EtatActuelle (arpenteur)} en ${this.CarteActuelle (arpenteur)} (Climat = ${arpenteur.getFlag(`a-perte-de-reve`, `Climat`)})`); 
        } else {
            ui.notifications.info(`OUTRE-REVE || ${arpenteur.name} n'a pas le Don d'Arpenter le Fleuve`); 
        }
    }
    static async basculerTmrCEF (arpenteur, destination = "", forced = false) { 
        return arpenteur.CEF.basculerTmrCEF(destination, forced);
   }
}