import { SHOW_DICE, SYSTEM_RDD } from "/systems/foundryvtt-reve-de-dragon/module/constants.js";
import { RollDataAjustements } from "/systems/foundryvtt-reve-de-dragon/module/rolldata-ajustements.js";
import { RdDUtility } from "/systems/foundryvtt-reve-de-dragon/module/rdd-utility.js";
import { TMRUtility } from "/systems/foundryvtt-reve-de-dragon/module/tmr-utility.js";
import { RdDResolutionTable } from "/systems/foundryvtt-reve-de-dragon/module/rdd-resolution-table.js";
import { RdDTMRRencontreDialog } from "/systems/foundryvtt-reve-de-dragon/module/rdd-tmr-rencontre-dialog.js";
import { ChatUtility } from "/systems/foundryvtt-reve-de-dragon/module/chat-utility.js";
import { RdDRoll } from "/systems/foundryvtt-reve-de-dragon/module/rdd-roll.js";
import { Poetique } from "/systems/foundryvtt-reve-de-dragon/module/poetique.js";
import { EffetsDraconiques } from "/systems/foundryvtt-reve-de-dragon/module/tmr/effets-draconiques.js";
import { PixiTMR } from "/systems/foundryvtt-reve-de-dragon/module/tmr/pixi-tmr.js";
import { Draconique } from "/systems/foundryvtt-reve-de-dragon/module/tmr/draconique.js";
import { HtmlUtility } from "/systems/foundryvtt-reve-de-dragon/module/html-utility.js";
import { ReglesOptionnelles } from "/systems/foundryvtt-reve-de-dragon/module/settings/regles-optionnelles.js";
import { RdDDice } from "/systems/foundryvtt-reve-de-dragon/module/rdd-dice.js";
import { STATUSES } from "/systems/foundryvtt-reve-de-dragon/module/settings/status-effects.js";
import { RdDRencontre } from "/systems/foundryvtt-reve-de-dragon/module/item/rencontre.js";
import { ITEM_TYPES } from "/systems/foundryvtt-reve-de-dragon/module/constants.js";
import { Misc } from "/systems/foundryvtt-reve-de-dragon/module/misc.js";
import { RdDTMRDialog } from "/systems/foundryvtt-reve-de-dragon/module/rdd-tmr-dialog.js";
import { CarteTmr } from "/systems/foundryvtt-reve-de-dragon/module/tmr/carte-tmr.js";
import { EffetsRencontre } from "/systems/foundryvtt-reve-de-dragon/module/tmr/effets-rencontres.js";

export class CarteCEF extends CarteTmr {
    img()  { return RDD_CEF.Image;  }
    code() { return 'cef' }
    
    static rencontreSelonClimat(arpenteur){
        let clim = 0; // 0 : TMR = rencontre sur 7
        if (arpenteur.getFlag(`a-perte-de-reve`, `Imago`) == true) {
            clim = arpenteur.getFlag(`a-perte-de-reve`, `Climat`);
            //ui.notifications.info(`OUTRE-REVE || ${RDD_CEF.Climat[clim].label} Rencontre sur ${RDD_CEF.Climat[clim].jetRencontre}`);
        } else {
            //ui.notifications.info(`OUTRE-REVE || ${arpenteur.name} n'est pas en Imago, Rencontre TMR sur '7'`);
        }
        return RDD_CEF.Climat[clim]; 
    }
    static async changeClimat(arpenteur, rencontre){
        console.log(`OUTRE-REVE || CarteCEF - Change climat pour ${arpenteur}: `, rencontre);
        // ...
    }
    async AjusteClimat(mod){
        let clim = this.acteur.getFlag(`a-perte-de-reve`, `Climat`);
        clim += mod;
        if (clim < 1) {
          clim = 1;
        }else if (clim >= RDD_CEF.Climat.length){
          clim = RDD_CEF.Climat.length-1;
        }
        await arpenteur.setFlag(`a-perte-de-reve`, `Climat`, clim);
        ui.notifications.info('Changement du Climat :', RDD_CEF.Climat[clim].label, " - Rencontre sur ",RDD_CEF.Climat[clim].jetRencontre);
        return clim;
    }
    static async AjusteClimat(arpenteur, mod){
        let clim = arpenteur.getFlag(`a-perte-de-reve`, `Climat`);
        clim += mod;
        if (clim < 1) {
          clim = 1;
        }else if (clim >= RDD_CEF.Climat.length){
          clim = RDD_CEF.Climat.length-1;
        }
        await arpenteur.setFlag(`a-perte-de-reve`, `Climat`, clim);
        ui.notifications.info(RDD_CEF.Climat[clim].label, " - Rencontre sur ",RDD_CEF.Climat[clim].jetRencontre);
        return clim;
    }
    static _getCEF(coord) {
        //console.log("Coord=",coord, " ; type=", CEFMap[coord].type);
        return coord == FLEUVE_COORD ? CEFMap['D1'] : CEFMap[coord];
    }
    static getCEFLabel(coord) {
        //console.log("Coord=",coord, " ; type=", CEFMap[coord].type);
        return game.outreReve.CarteCEF._getCEF(coord)?.label ?? (coord + ": case inconnue");
    }
}
export class RdDCEFDialog extends RdDTMRDialog {
    static myTmrApps = new Array(); // liste des instance RdDCEFDialog
    async close() { //$forceClose(message) {
        // PENDING : Cleanup de la fatigue avant descente !!!
        const index = RdDCEFDialog.myTmrApps.indexOf(this);
        if (index > -1) { // only splice array when item is found
            //console.log('OUTRE-REVE || RdDCEFDialog closing - splicing ', RdDCEFDialog.myTmrApps[index]);
            RdDCEFDialog.myTmrApps.splice(index, 1);
        }
        return await super.close();
    }
    static async create(actor, tmrData) {
        console.log(`OUTRE-REVE || RdDCEFDialog - creation de RdDCEFDialog pour ${actor.name}. tmr data = `, tmrData);
        if (tmrData.mode != 'visu' && !game.user.isGM) {
            ChatMessage.create({ content: actor.name + " est monté dans les TMR/CEF en mode : " + tmrData.mode, whisper: ChatUtility.getGMs() });
        }
        await PixiTMR.init()
        let html = await renderTemplate('systems/foundryvtt-reve-de-dragon/templates/dialog-tmr.hbs', tmrData);
    /** PENDING: 
         *  ajouter les modification du Dialog pour ajout du boutton "Bascule" */
        let result = new RdDCEFDialog(html, actor, tmrData);
        RdDCEFDialog.myTmrApps.push(result);
        //console.log('OUTRE-REVE || RdDCEFDialog opening - myTmrApps.length ', RdDCEFDialog.myTmrApps.length);
        game.outreReve.OutreReve.refreshCarte(actor); // initialise sur la bonne carte
        return result;
    }
    async _jetDeRencontre(tmr){  // from rdd-tmr-dialog - line 669
        let carteActuelle = this.actor.CEF.CarteActuelle();
        game.outreReve.CEFRencontres.setTableRencontre(carteActuelle, this.actor);
        //console.log(`OUTRE-REVE || RdDCEFDialog - Jet de Rencontre en ${carteActuelle} : `, tmr);
        let tableRencontre = game.system.rdd.rencontresTMR;
        let rencontre = this.lookupRencontreExistente(tmr);
        if (rencontre) {
          return tableRencontre.calculRencontre(rencontre, tmr);
        }
        const coordTMR = (this.isDemiReveCache()
          ? TMRUtility.getTMRType(tmr.coord) + " ??"
          : tmr.label + " (" + tmr.coord + ")");
      
        this.setTMRPendingAction({ bringToTop: () => { } })
        const myRoll = await RdDDice.rollTotal((carteActuelle == "TMR") ? "1dt" : "1d8", { showDice: SHOW_DICE });
        this.restoreTMRAfterAction()
        
        let clim = CarteCEF.rencontreSelonClimat(this.actor);
        if (myRoll >= clim.jetRencontre) { 
            this._tellToUser("<b>" + myRoll + ": Rencontre </b> en " + coordTMR + " !!!<br>   <i> " + clim.label + " = rencontre sur " + clim.jetRencontre + "</i>");
            rencontre = await tableRencontre.getRencontreAleatoire(tmr, this.actor.isMauvaiseRencontre());
            // RENCONTRE influe sur le climat
            // ...
            CarteCEF.changeClimat(this.actor, rencontre);
            return rencontre;
        } else {
            this._tellToUser("<b>" + myRoll + ": Pas de rencontre </b> en " + coordTMR + "<br>   <i> " + clim.label + " = rencontre sur " + clim.jetRencontre + "</i>");
            return undefined;
        }
    }
}
export const cartesHR = {
    TMR: new CarteTmr(),
    CEF: new CarteCEF()
}