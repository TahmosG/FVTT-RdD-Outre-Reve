import { TMRRencontres } from "/systems/foundryvtt-reve-de-dragon/module/tmr-rencontres.js";
import { EffetsRencontre } from "/systems/foundryvtt-reve-de-dragon/module/tmr/effets-rencontres.js";
import { RdDRencontre, tableEffets } from "/systems/foundryvtt-reve-de-dragon/module/item/rencontre.js"; // add line 4: "export"
import { CompendiumTable } from "/systems/foundryvtt-reve-de-dragon/module/settings/system-compendiums.js";
import { Misc } from "/systems/foundryvtt-reve-de-dragon/module/misc.js";
import { RdDTMRRencontreDialog } from "/systems/foundryvtt-reve-de-dragon/module/rdd-tmr-rencontre-dialog.js";

/** TO DO
 *  [V] Liste de Rencontre pour CEF
 *  [V] Probabilite de Rencontre selon Climat (type de rencontre ignoree selon niveau)
 *  [x] Chaque Rencontre influe sur le CLimat 
 *  [x] Possibilite de gerer manuellement les Rencontres --> hijack Rencontre dialog
 */
export class CEFRencontres extends TMRRencontres {
  static TableRencontre = { };
  static init() {
    CEFRencontres.TableRencontre = { // .table pour acceder a la table en elle-même
      TMR : new CEFRencontres('rencontres'),
      CEF : new CEFRencontres(`a-perte-de-reve.rencontres-cef`)
    };
    this.setTableRencontre();
  }
  constructor(compendium) { // --> hijack OP constructor !
    super();
    this.table = new CompendiumTable(compendium, 'Item', 'rencontre', Misc.ascending(it => it.system.ordreTri));
  }
  static setTableRencontre(carte = "TMR", acteur){
    game.system.rdd.rencontresTMR = this.TableRencontre[carte];
    CEFRencontres.arpenteurActif = acteur;
    //console.log(`OUTRE-REVE || Rencontres sur la table`, carte, ":", game.system.rdd.rencontresTMR);
  }

  async getRencontreAleatoire(tmr, mauvaise) {
    //le niveau minimum de la rencontre, selon le climat
    let niveauMin = CEFRencontres.arpenteurActif.CEF.RencontreMin();
    const codeTerrain = mauvaise ? 'mauvaise' : tmr.type;
    // setup des filtres (terrain, frequence, niveauMin)
    const filtre = codeTerrain == 'mauvaise' ? it => it.system.mauvaiseRencontre : it => !it.system.mauvaiseRencontre && (it.system.ordreTri >= niveauMin ) ;
    const frequence = it => it.system.frequence[codeTerrain];
    // Affiche les Rencontres potentielles dans le tchat
    this.table.toChatMessage(frequence, filtre); 
    
    // Tirer la rencontre (selon les filtres)
    const row = await this.table.getRandom(frequence, filtre);
    // Appliquer les effets
    if (row) {
      const rencontre = await this.createRencontre(row.document, tmr);
      await this.$chatRolledRencontre(row, rencontre, tmr);
      return rencontre;
    }
    return undefined;
  }
}
// ==================================================
export class EffetsCEF extends EffetsRencontre {
  // ajout du changement de Climat (set et +/-)
}
// ==================================================

export class RdDRencontreCEF extends RdDRencontre {

  static init(){
    // ajout de NOUVEAUX EFFETS  --> "rencontre.js" 
    tableEffets.push(    /* resultat: "auto" --> pour traitement automatique (et liste en succes et echec) */
      { code: "climat+1", resultat: "echec", description: "le climat CEF monte de 1", method: EffetsRencontre.climat_plus_1 },
      { code: "climat-1", resultat: "echec", description: "le climat CEF descend de 1", method: EffetsRencontre.climat_moins_1 },
    );
    // ajout en UTIL... mais la plupart des Classes utilisent la version originale (en import)
    game.system.rdd.itemClasses.rencontre = RdDRencontreCEF;
  }

  // -------------- UNUSED -----------------------------------------------------------------------------------------
  static get defaultIcon() {
    return ( game.outreReve.Arpenteur.selected().isImago() == false ) 
      ? "systems/foundryvtt-reve-de-dragon/icons/tete_dragon.webp"    // icone en TMR
      : "systems/foundryvtt-reve-de-dragon/icons/queue_dragon.webp" ;   // icone en CEF
  }

  static getEffetsSucces() { return RdDRencontreCEF.getEffets("succes"); }
  static getEffetsEchec() { return RdDRencontreCEF.getEffets("echec"); }
  static getEffetsAutomatique() { return RdDRencontreCEF.getEffets("auto"); }

  static getEffets(resultat) {
    return tableEffets.filter(e => resultat == e.resultat);
  }
  
  static mapEffets(liste) {
    return liste.map(it => RdDRencontre.getEffet(it));
  }
  
  // pas besoin ???
  static getListeEffets(item, reussite) {
    if (reussite == 'echec') {
      return [...item.system.echec.effets];
    }
    if (reussite == 'succes') {
      return [...item.system.succes.effets];
    }
    if (reussite == 'auto') {
      return [...item.system.auto.effets];    // a tester
    }
    return [];
  }  
}