carte-TMR.js --> config du background
//const TMR_CEF = "modules/a-perte-de-reve/assets/tmr-CEF.webp";  --> carte-tmr.js - line 37

tmr-utility.js // --> declaration de TMRMap et CEFMap (nom des cases) puis
export var TMRMapping = TMRMap; //Tahmos 


//              LIB-WRAPPER : https://github.com/ruipin/fvtt-lib-wrapper
//             ============= 

//  code pour trouver l'ID d'une fonction a wrapper (apparement incompatible avec fvtt-rdd)
Hooks.on("libWrapper.Register", function(PackageID, target, WrapperType, Options, WrapperID ) {
  //details d'access pour le WRAPPER
  console.log(`CEF UTILS - Wrapper from: ${PackageID}`);
  console.log(`CEF UTILS -      Target = ${target}`);
  console.log(`CEF UTILS -        Type = ${WrapperType}`);
  console.log(`CEF UTILS -          ID = ${WrapperID}`);
});

function initWrapper() {
  console.log("OUTRE-REVE || (onReady) Initializing Wrappers");
  // code pour enregistre un wrapper sur la fonction identifiee precedement ^^
  libWrapper.register('a-perte-de-reve', 'OutreReve.isArpenteur', function (wrapped, ...args) { //RdDTMRDialog._jetDeRencontre
    //const actor = this.actor;  // you should have access to `this` in here as well
    // ... do things ...
    const result = wrapped(...args); // remember to call the original (wrapped) method
    // ... do things ...
    return result; // this return needs to have the same shape (signature) as the original, or things start breaking
  });
};