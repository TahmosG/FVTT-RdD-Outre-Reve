/*class Arpenteur {

    static async toggleStatus(arpenteur){
        if (arpenteur.getFlag(`a-perte-de-reve`, `isArpenteur`) == true){
            let imago = arpenteur.getFlag(`a-perte-de-reve`, `CEF_Imago`);
            await arpenteur.setFlag(`a-perte-de-reve`, `CEF_Imago`, !imago);
            let carte = this.CarteActuelle (arpenteur);
            ui.notifications.info(`OUTRE-REVE || ${arpenteur.name} bascule en ${carte}`); 
            return carte;
        } else {
            ui.notifications.info(`${arpenteur.name} n'est pas un Arpenteur`);
            return false;
        }
    }

    static isArpenteur(selected){
        if (!selected) { 
          // pas de perso selectionné
          ui.notifications.info(`Pas de personnage sélectionné`);
          return false;
        }    
        if (selected.getFlag(`a-perte-de-reve`, `isArpenteur`) == true){
          // deja FLAG arpenteur
          return true;
        }else{
          // pas de FLAG arpenteur
          return this.initFlags (selected);
        }
    }

    static LogArpenteur (arpenteur) { 
        let arp = arpenteur.getFlag(`a-perte-de-reve`, `isArpenteur`);
        if ( arp == true){
            ui.notifications.info(`OUTRE-REVE || ${arpenteur.name} a son ${this.EtatActuelle (arpenteur)} en ${this.CarteActuelle (arpenteur)} (Climat = ${arpenteur.getFlag(`a-perte-de-reve`, `CEF_Climat`)})`); 
        } else {
            ui.notifications.info(`OUTRE-REVE || ${arpenteur.name} n'a pas le Don d'Arpenter le Fleuve`); 
        }
    }
    
    static CarteActuelle (arpenteur) { 
        let imago = arpenteur.getFlag(`a-perte-de-reve`, `CEF_Imago`);
        if (imago == true) {
            return "CEF";
        } else {
            return "TMR";
        }
    }
    
    static EtatActuelle (arpenteur) { 
        let imago = arpenteur.getFlag(`a-perte-de-reve`, `CEF_Imago`);
        if (imago == true) {
            return "Imago";
        } else {
            return "Demi-Rêve";
        }
    }

    static ClimatActuel (arpenteur) { 
        return arpenteur.getFlag(`a-perte-de-reve`, `CEF_Climat`);
    }

    static async initFlags (arpenteur, climat = 0){
        console.log("Initialization des FLAGs d'arpentage");
        if (arpenteur.items.filter(item => item.name == "Don d'Arpenter le Fleuve").length){ 
            // possede le Don
            await arpenteur.setFlag(`a-perte-de-reve`, `isArpenteur`, true);
            await arpenteur.setFlag(`a-perte-de-reve`, `CEF_Imago`, true);
            await arpenteur.setFlag(`a-perte-de-reve`, `CEF_Climat`, climat);
            ui.notifications.info(`OUTRE-REVE || Initialization des FLAGs d'arpentage pour ${arpenteur.name}`); 
            return true;
          }else{
            // n'a pas le Don
            await arpenteur.setFlag(`a-perte-de-reve`, `isArpenteur`, false);
            await arpenteur.setFlag(`a-perte-de-reve`, `CEF_Imago`, "N/A");
            await arpenteur.setFlag(`a-perte-de-reve`, `CEF_Climat`, "N/A");
            ui.notifications.info(`OUTRE-REVE || ${arpenteur.name} n'a pas le don d'arpentage`); 
            return false; 
          }
    }
    
    static async clearFlags (arpenteur) { 
        const confirm = await Dialog.confirm({ 
            content: `Etes-vous sur de vouloir reinitialiser les Flags? \n (Climat actuel == ${this.ClimatActuel(arpenteur)})`,
        })
        if (!confirm){ return; } 
        await arpenteur.unsetFlag(`a-perte-de-reve`, `isArpenteur`);
        await arpenteur.unsetFlag(`a-perte-de-reve`, `CEF_Imago`);
        await arpenteur.unsetFlag(`a-perte-de-reve`, `CEF_Climat`);
        ui.notifications.info(`OUTRE-REVE || Reset des FLAGs d'arpentage pour ${arpenteur.name}`); 
    }

}*/